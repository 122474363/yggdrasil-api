<?php

// In seconds
define('YGG_TOKEN_EXPIRE', 604800);
