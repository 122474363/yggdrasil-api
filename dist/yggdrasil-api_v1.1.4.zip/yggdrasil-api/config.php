<?php

// In seconds
define('YGG_TOKEN_EXPIRE', 604800);

define('YGG_VERBOSE_LOG', false);
