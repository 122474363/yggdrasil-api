<?php

return function () {
    View::alias('Blessing\IndexImgFixedStyle::index', 'index');
};
