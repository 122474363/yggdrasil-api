/*
* @Author: printempw
* @Date:   2017-01-02 14:05:39
* @Last Modified by:   printempw
* @Last Modified time: 2017-01-02 14:19:32
*/

$.extend($.locales['zh_CN'], {
    'examplePlugin': {
        test: "JavaScript i18n test: 简体中文"
    }
});
