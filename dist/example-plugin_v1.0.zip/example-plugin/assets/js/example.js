/*
* @Author: printempw
* @Date:   2016-12-31 15:52:43
* @Last Modified by:   printempw
* @Last Modified time: 2017-01-02 14:22:11
*/

'use strict';

console.info("示例：使用 Hook::addScriptFileToPage() 加载插件目录下的文件到每个页面");

console.info("Javascript i18n example, calling trans('examplePlugin.test'): ");
console.log("Result: " + trans('examplePlugin.test'));
