/*
* @Author: printempw
* @Date:   2016-12-31 15:52:43
* @Last Modified by:   printempw
* @Last Modified time: 2016-12-31 16:03:50
*/

'use strict';

console.warn("示例：使用 plugin_assets() 从插件目录下加载文件");
